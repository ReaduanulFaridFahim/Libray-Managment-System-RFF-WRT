package interfaces;

import borrowoperations.*;

public interface IBorrowOperations
{
	public void borrowAbook(Borrow br);
	public void returnbook(int lcdno);
	
	
}