package interfaces;

import book.Book;
import author.Author;
import publisher.Publisher;

public interface IBookOperations{
	public void insertBook(Book b);
	public Book getBook(int bookId);
	public void showAllBooks();
	
}