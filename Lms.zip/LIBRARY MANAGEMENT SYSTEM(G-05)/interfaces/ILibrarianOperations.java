package interfaces;

import librarian.Librarian;
import common.Common;


public interface ILibrarianOperations{
	public void insertLibrarian(Librarian l);
	public void removeLibrarian(int librarianId);
	public Librarian getLibrarian(int librarianId);
	public void showAllLibrarians();
}