package interfaces;

import student.Student;
import common.Common;

public interface IStudentOperations{
	 public void insertStudent(Student S);
	 public void removeStudent(int id);
	 public Student getStudent(int id);
	 public void showAllStudents();
}