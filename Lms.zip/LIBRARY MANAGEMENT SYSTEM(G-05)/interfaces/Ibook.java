package interfaces;

import author.Author;
import publisher.Publisher;

public interface Ibook{
	public void setAuthor(Author author);
	public void setPublisher(Publisher publisher);
}