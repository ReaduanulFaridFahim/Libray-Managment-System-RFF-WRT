package borrowoperations;
public class Borrow
{
	private String lcdno;
	private String nme;
	private String bname;
	private String bid;
	private String phnum;
	private String days;
	

    public void setLcdno(String lcdno) 
	{
		this.lcdno=lcdno;
	}
	public void setNme(String nme) 
	{
		this.nme=nme;
	}
	public void setBname(String bname) 
	{
		this.bname=bname;
	}
	public void setBid(String bid) 
	{
		this.bid=bid;
	}
	public void setPhnum(String phnum) 
	{
		this.phnum=phnum;
	}
	public void setDays(String days) 
	{
		this.days=days;
	}

	public String getLcdno() 
	{
		return this.lcdno;
	}
	public String getNme() 
	{
		return this.nme=nme;
	}
	public String getBname() 
	{
		return this.bname;
	}
	public String getBid() 
	{
		return this.bid;
	}
	public String getPhnum() 
	{
		return this.phnum;
	}
	public String getDays() 
	{
		return this.days=days;
	}






}