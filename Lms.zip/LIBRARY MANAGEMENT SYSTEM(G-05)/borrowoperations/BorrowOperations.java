package borrowoperations;
import borrowoperations.*; 
import interfaces.*;
import java.io.*;
import java.util.Scanner;

public class BorrowOperations implements IBorrowOperations
{   
    String lid;
	Borrow br;
	FileReader fileReader=null;
	FileWriter fileWriter=null;
    File file = new File("BORROW_RECORDINGS.txt");
	Scanner input=new Scanner(System.in);


	     public void borrowAbook(Borrow br){
			this.br=br;
			System.out.println("Enter Library ID:");
			String lcd=input.nextLine();
			br.setLcdno(lcd);
            System.out.println("Enter Your Name:");
            String nme=input.next();
            br.setNme(nme); 
			System.out.println("Enter Book Name:");
			String n=input.next();
			br.setBname(n);
			input.nextLine();		
			System.out.println("Enter Book ID: ");
			String bid=input.nextLine();
			br.setBid(bid);
			System.out.println("Enter your PhoneNumber:");
			String phnum=input.nextLine();
			br.setPhnum(phnum);
            System.out.println("How many days you want to borrow:");
            String days=input.nextLine();
            br.setDays(days);
			System.out.println("Your Given Informations Are:");
			System.out.println("Library ID:"+br.getLcdno());
            System.out.println("Enter Your Name:"+br.getNme());
			System.out.println("Enter Book Name:"+br.getBname());
			System.out.println("Enter Book ID:"+br.getBid());
			System.out.println("Phone Number:"+br.getPhnum());
            System.out.println("Duraion:"+br.getDays());
			System.out.println("Are are the Informations Correct?(y/n)");
			char ch=input.next().charAt(0);
			if(ch=='y') {
			try{
            
                fileWriter = new FileWriter(file, true);
                fileWriter.write("\nLibrary ID:"+br.getLcdno()+"\nEnter Your Name:"+br.getNme()+"\nEnter Book name:"+br.getBname()+"\nEnter Book ID:"+br.getBid()+"\nPhone Number:"+br.getPhnum()+"\nDuraion:"+br.getDays());
                System.out.println("THANK YOU. PLEASE TRY TO RETURN IT WITHIN "+br.getDays()+" DAYS");
            }
            catch(Exception ex) {
                System.out.println("Exception caught!!");
            }
            finally {
                try {
                    fileWriter.close();
                }
                catch(Exception ex) {
                    System.out.println("Can not close the resource!!");
                }
            }
        }
        else{
            System.out.println("Please Try Again");
        
		}
		
}
        public void returnbook(int lcdno){
        this.br=br;
        System.out.println("Enter Library ID: ");
        lid=Integer.toString(lcdno);
        String line=null;
        boolean isContaintFound=false;
        int count = 0;
        int numberOfLineDlete=6;
        String input="";
        try{
            fileReader = new FileReader(file);
            BufferedReader linRead= new BufferedReader(fileReader);
            while ((line = linRead.readLine()) != null) {
                if (line.contains(lid)) {
                    isContaintFound = true;
                    line=null;
                    count++;
                    continue;
                }
                else if(isContaintFound && count < numberOfLineDlete){
                    count++;
                    line=null;
                }
                else if (isContaintFound && count == numberOfLineDlete) {
                    line=null;
                    isContaintFound = false;
                }
                else{
                    input += line + '\n';
                }
            }
            fileWriter = new FileWriter(file);
            fileWriter.write(input);
            System.out.println("THANK YOU FOR RETURNING THE BOOK");
        }
        catch(Exception ex) {
            System.out.println("Exception caught!!");
        }
        finally {
            try {
                fileWriter.close();
                fileReader.close();
            }
            catch(Exception ex) {
                System.out.println("Can not close the resource!!");
            }
        }
    }



}
	
	
	
					
			
		
		
				
	

