package common;

public abstract class Common{
    private String id;
    private String name;
    private String departmentName;
    private String email;
    private String contactNo;
    private String address;


    public void setId(String id){
        this.id=id;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setDepartmentName(String departmentName){
        this.departmentName=departmentName;
    }

    public void setEmail(String email){
        this.email=email;  
    }
    public void setContactNo(String contactNo){
        this.contactNo=contactNo;
    }
    public void setAddress(String address){
        this.address=address;
    }
    public String getId(){
        return id;
    }
    
    public String getName(){
        return name;
    }
    public String getDepartmentName(){
        return departmentName;
    }
    public String getEmail(){
        return email;
    }
    public String getContactNo(){
        return contactNo;
    }
    public String getAddress(){
        return address;
    }
    public abstract void showInfo();
}