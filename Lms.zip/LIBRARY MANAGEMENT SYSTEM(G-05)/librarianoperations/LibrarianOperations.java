package librarianoperations;

import librarian.Librarian;
import common.Common;
import interfaces.ILibrarianOperations;
import java.util.Scanner;
import java.io.*;

public class LibrarianOperations implements ILibrarianOperations{
    File file = new File("LIBRARIAN_DATA.txt");
    FileWriter fileWriter = null;
    FileReader fileReader=null;
    String line;
    boolean isContaintFound;
    int count;
    Scanner in=new Scanner(System.in);
    String id;

    public void insertLibrarian(Librarian l){
        System.out.println("Enter  Librarians's ID: ");
        String lid=in.nextLine();
        l.setLibrarianId(lid);
        System.out.println("Enter  Librarian's Name: ");
        String lname=in.nextLine();
        l.setName(lname);
        System.out.println("Enter  Librarian's Depertment Name: ");
        String ldepartmentName=in.nextLine();
        l.setDepartmentName(ldepartmentName);
        System.out.println("Enter  Librarian's email: ");
        String lemail=in.nextLine();
        l.setEmail(lemail);
        System.out.println("Enter  Librarian's contactNo: ");
        String lcontactNo=in.nextLine();
        l.setContactNo(lcontactNo);
        System.out.println("Enter  Librarian's address: ");
        String saddress=in.nextLine();
        l.setAddress(saddress);

        System.out.println("\n\nPlease check all information:");
        l.showInfo();
        char choice;
        System.out.println("\n\t\t\tIs all the information correct?(y/n)\t\t\t");
        choice=in.next().charAt(0);
        if(choice=='y'){
            try {
            
                fileWriter = new FileWriter(file, true);
                fileWriter.write("\nLibrarian ID: "+l.getLibrarianId()+"\nName: "+l.getName() +"\nDepartment Name: "+l.getDepartmentName()+
                "\nEmail: "+l.getEmail()+"\nContact No: "+l.getContactNo()+"\nAddress: "+l.getAddress());
                System.out.println("Information Sucessfully added!!!");
            }
            catch(Exception ex) {
                System.out.println("Exception caught!!");
            }
            finally {
                try {
                    fileWriter.close();
                }
                catch(Exception ex) {
                    System.out.println("Can not close the resource!!");
                }
            }
        }
        else{
            System.out.println("Please Try Again");
        }  
    }


public void removeLibrarian(int librarianId){
        
        id = Integer.toString(librarianId);
        line=null;
        isContaintFound=false;
        count = 0;
        int numberOfLineDlete=7;
        String input="";
        try{
            fileReader = new FileReader(file);
            BufferedReader linRead= new BufferedReader(fileReader);
            while ((line = linRead.readLine()) != null) {
                if (line.contains(id)) {
                    isContaintFound = true;
                    line=null;
                    count++;
                    continue;
                }
                else if(isContaintFound && count < numberOfLineDlete){
                    count++;
                    line=null;
                }
                else if (isContaintFound && count == numberOfLineDlete) {
                    line=null;
                    isContaintFound = false;
                }
                else{
                    input += line + '\n';
                }
            }
            fileWriter = new FileWriter(file);
            fileWriter.write(input);
            System.out.println("Librarian Successfully Deleted!!!");
        }
        catch(Exception ex) {
            System.out.println("Exception caught!!");
        }
        finally {
            try {
                fileWriter.close();
                fileReader.close();
                
            }
            catch(Exception ex) {
                System.out.println("Can not close the resource!!");
            }
        }

    }





    public Librarian getLibrarian(int librarianId){
        
        Librarian lb=new Librarian(); 
        id = Integer.toString(librarianId);
        int numberOfLinePrint=6;
        try{
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            line=null;
            isContaintFound=false;
            count = 0;
            while ((line = bufferedReader.readLine()) != null) {
                if (line.contains(id)) {
                    isContaintFound = true;
                    System.out.println(line);
                    count++;
                    continue;
                }
                else if(isContaintFound && count < numberOfLinePrint){
                    count++;
                    System.out.println(line);
                }
                else if (isContaintFound && count == numberOfLinePrint) {
                    System.out.println(line);
                    isContaintFound = false;
                }
            }
        }
        catch(Exception ex) {
            System.out.println("Exception caught!!");
        }
        finally {
            try {
                fileReader.close();
            }
            catch(Exception ex) {
                System.out.println("Can not close the resource!!");
            }
        }
        return lb;
    }

    public void showAllLibrarians(){
        try{
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        }
        catch(Exception ex) {
            System.out.println("Exception caught!!");
        }
        finally {
            try {
                fileReader.close();
            }
            catch(Exception ex) {
                System.out.println("Can not close the resource!!");
            }
        } 
    }
}