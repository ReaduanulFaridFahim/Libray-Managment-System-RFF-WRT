package librarian;
import common.Common;

public class Librarian extends Common{
    private String librarianId;

    public void setLibrarianId(String librarianId){
        this.librarianId=librarianId;
    }
    public String getLibrarianId(){
        return librarianId;
    }
    public void showInfo(){
        System.out.println("Library ID: "+getLibrarianId());
        System.out.println("Name: "+getName());
        System.out.println("Department Name: "+getDepartmentName());
        System.out.println("Email: "+getEmail());
        System.out.println("Contact No: "+getContactNo());
        System.out.println("Address: "+getAddress());
    }
    
}